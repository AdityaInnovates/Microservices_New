"use strict";
exports.id = 100;
exports.ids = [100];
exports.modules = {

/***/ 8100:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _context_allcontexts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3534);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);




const FloatingButton = (props)=>{
    const { canGoBack , setcanGoBack  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_allcontexts__WEBPACK_IMPORTED_MODULE_2__/* .User */ .n);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "fixed flex justify-end items-end w-[100%] h-[88.8%] pointer-events-none z-10",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "mb-[3rem] mr-[3rem] bg-black rounded-[100%] pointer-events-auto",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "p-5 pointer-events-auto cursor-pointer",
                    onClick: ()=>{
                        if (canGoBack) {
                            next_router__WEBPACK_IMPORTED_MODULE_3___default().push("/internSearch");
                        } else {
                            next_router__WEBPACK_IMPORTED_MODULE_3___default().push("/submitTask");
                        }
                    },
                    children: canGoBack ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        crossOrigin: "anonymous",
                        className: "w-[2rem] invert pointer-events-auto",
                        src: "/left-arrow.svg",
                        alt: ""
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        crossOrigin: "anonymous",
                        className: "w-[2rem] rotate-45 invert pointer-events-auto",
                        src: "/close-cross.svg",
                        alt: ""
                    })
                })
            })
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FloatingButton);


/***/ }),

/***/ 3534:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "n": () => (/* binding */ User)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const User = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)();


/***/ })

};
;