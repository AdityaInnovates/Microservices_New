"use strict";
exports.id = 134;
exports.ids = [134];
exports.modules = {

/***/ 134:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2947);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_3__);






const AsideNav = (props)=>{
    let Arrofdat = props.asideData || [
        "Account",
        "Addresses",
        "How To Sell?",
        "Debit/Credit Cards",
        "SignOut", 
    ];
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "bg-white m-[.5rem] rounded-sm shadow-md ",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                    className: ` flex flex-col space-y-2 pl-[.5rem] pb-[1rem] min-w-[5rem] md:min-w-[13rem] min-h-[17rem] max-h-[87vh] pr-[4rem] pt-[1rem] overflow-x-hidden overflow-y-auto `,
                    children: Arrofdat.map((el1)=>{
                        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                            className: `${props.data === el1 ? "bg-[#e5e7eb]" : ""} asideitem hover:bg-cyan-300 pl-[.5rem] w-[130%] rounded-sm cursor-pointer mb-1 pt-1`,
                            onClick: (e)=>{
                                props.setdata(e.currentTarget.firstChild.textContent);
                                jquery__WEBPACK_IMPORTED_MODULE_3___default()(e.currentTarget).parent().children().each((ind, el)=>{
                                    el.removeAttribute("style");
                                });
                                jquery__WEBPACK_IMPORTED_MODULE_3___default()(e.currentTarget).parent().children().each((ind, el)=>{
                                    el.firstChild.firstChild.checked = false;
                                });
                                e.currentTarget.firstChild.firstChild.checked = true;
                                e.currentTarget.style.backgroundColor = "#e5e7eb";
                            },
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex items-baseline gap-2",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "checkbox"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                            className: "mb-1.5 mt-1 cursor-pointer",
                                            children: el1
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                    className: "w-[100%]"
                                })
                            ]
                        }, el1));
                    })
                })
            })
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AsideNav);


/***/ })

};
;