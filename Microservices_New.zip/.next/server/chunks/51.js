"use strict";
exports.id = 51;
exports.ids = [51];
exports.modules = {

/***/ 7051:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_Sidebar)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "jquery"
var external_jquery_ = __webpack_require__(2947);
var external_jquery_default = /*#__PURE__*/__webpack_require__.n(external_jquery_);
;// CONCATENATED MODULE: ./components/subComponents/datafordoc.jsx


const datafordoc = (props)=>{
    // console.log(props);
    // let pop = new Array(props);
    let pop = props.data;
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: pop.map((e)=>{
            e = JSON.parse(e);
            return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "mt-9 ml-10",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        id: `${props.class}`,
                        className: `text-xl mb-1 font-medium`,
                        children: e.header
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: e.content
                    })
                ]
            }, e.header));
        })
    }));
};
/* harmony default export */ const subComponents_datafordoc = (datafordoc);

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
var router_default = /*#__PURE__*/__webpack_require__.n(router_);
;// CONCATENATED MODULE: ./components/Sidebar.js







const Sidebar = (props)=>{
    const { 0: datafordisplay , 1: setdatafordisplay  } = (0,external_react_.useState)([]);
    function applydata(e) {
        external_jquery_default().ajax({
            type: "post",
            url: `/api/fectdatafordoc/${e.currentTarget.innerText}`,
            success: (data)=>{
                fixbugforjson(data);
            },
            error: (err)=>{
                console.log(err);
            }
        });
    }
    let classtosend = "Introduction";
    function fixbugforjson(data) {
        setdatafordisplay([]);
        let arr = new Array();
        let data1 = data.substring(1, data.length - 1).split("},");
        data1.forEach((e, index)=>{
            if (index !== data1.length - 1) {
                data1[index] = data1[index] + "}";
                arr.push(data1[index]);
            } else {
                setdatafordisplay(arr);
            }
        });
    }
    // console.log(datafordisplay);
    (0,external_react_.useEffect)(()=>{
        external_jquery_default().ajax({
            type: "post",
            url: `/api/fectdatafordoc/${props.load}`,
            success: (data)=>{
                fixbugforjson(data);
            // setdatafordisplay(data);
            },
            error: (err)=>{
                console.log(err);
            }
        });
    }, [
        (external_jquery_default())
    ]);
    return(/*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-row space-x-40 ",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "mt-3 ml-8 fixed",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                            className: "font-medium",
                            children: "GET STARTED"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                            className: "space-y-4 mt-2",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: "itemsofsidebar cursor-pointer hover:text-sky-500",
                                    // onClick={(e) => {
                                    // classtosend = e.currentTarget.innerText;
                                    // $.ajax({
                                    //   type: "post",
                                    //   url: `/api/fectdatafordoc/${e.currentTarget.innerText}`,
                                    //   success: (data) => {
                                    //     fixbugforjson(data);
                                    //   },
                                    //   error: (err) => {
                                    //     console.log(err);
                                    //   },
                                    // });
                                    // }}
                                    onClick: (e)=>{
                                        router_default().replace(`${e.currentTarget.innerText}`);
                                        applydata(e);
                                    },
                                    children: "Introduction"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: `itemsofsidebar cursor-pointer hover:text-sky-500 ${"pl-3"}`,
                                    onClick: (e)=>{
                                        if (external_jquery_default()(`h1:contains('${e.currentTarget.innerText}')`)[0]) {
                                            external_jquery_default()(`h1:contains('${e.currentTarget.innerText}')`)[0].scrollIntoView();
                                        }
                                    },
                                    children: "Overview"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: `itemsofsidebar cursor-pointer hover:text-sky-500 ${"pl-3"}`,
                                    onClick: (e)=>{
                                        if (external_jquery_default()(`h1:contains('${e.currentTarget.innerText}')`)[0]) {
                                            console.log(external_jquery_default()(`h1:contains('${e.currentTarget.innerText}')`));
                                            external_jquery_default()(`h1:contains('${e.currentTarget.innerText}')`)[0].scrollIntoView();
                                        }
                                    },
                                    children: "Key concepts"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: "itemsofsidebar cursor-pointer hover:text-sky-500",
                                    onClick: (e)=>{
                                        router_default().replace(`${e.currentTarget.innerText}`);
                                        applydata(e);
                                    },
                                    children: "Quickstart tutorial"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: "itemsofsidebar cursor-pointer hover:text-sky-500",
                                    onClick: (e)=>{
                                        router_default().replace(`${e.currentTarget.innerText}`);
                                        applydata(e);
                                    },
                                    children: "Libraries"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: "itemsofsidebar cursor-pointer hover:text-sky-500",
                                    onClick: (e)=>{
                                        router_default().replace(`${e.currentTarget.innerText}`);
                                        applydata(e);
                                    },
                                    children: "Engines"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: "itemsofsidebar cursor-pointer hover:text-sky-500",
                                    onClick: (e)=>{
                                        router_default().replace(`${e.currentTarget.innerText}`);
                                        applydata(e);
                                    },
                                    children: "Usage guidelines"
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: " max-w-[50%]",
                    children: datafordisplay !== "" ? /*#__PURE__*/ jsx_runtime_.jsx(subComponents_datafordoc, {
                        data: datafordisplay,
                        class: classtosend
                    }) : ""
                })
            ]
        })
    }));
};
/* harmony default export */ const components_Sidebar = (Sidebar);


/***/ })

};
;