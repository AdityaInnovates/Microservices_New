"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 3534:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "n": () => (/* binding */ User)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const User = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)();


/***/ }),

/***/ 8522:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "jquery"
var external_jquery_ = __webpack_require__(2947);
var external_jquery_default = /*#__PURE__*/__webpack_require__.n(external_jquery_);
;// CONCATENATED MODULE: ./components/subComponents/floatingProfileView.jsx



const FloatingProfileView = ()=>{
    const { 0: user , 1: setuser  } = (0,external_react_.useState)("");
    function parseJwt(token) {
        var base64Url = token.split(".")[1];
        var base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
        var jsonPayload = decodeURIComponent(atob(base64).split("").map(function(c) {
            return "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2);
        }).join(""));
        setuser(JSON.parse(jsonPayload));
        return JSON.parse(jsonPayload);
    }
    // console.log(
    //   user.display_name
    //     ? `https://avatars.dicebear.com/api/initials/${user.display_name
    //         .replaceAll(" ", "")
    //         .replaceAll(",", " ")}.svg`
    //     : ""
    // );
    (0,external_react_.useEffect)(()=>{
        parseJwt(localStorage.getItem("access_token"));
    }, []);
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "absolute t-[2rem] translate-x-[-13rem] rounded-md min-h-[18rem] min-w-[18rem] block border-2 bg-white z-[99] border-slate-200 drop-shadow-lg shadow-xl",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex flex-col px-10 w-[100%]",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "pt-1 w-[100%] flex flex-col items-center gap-2",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            crossOrigin: "anonymous",
                            className: "rounded-[150%] w-[3.2rem] h-[3.2rem] mt-3 object-cover",
                            // src="https://lh3.googleusercontent.com/a-/AOh14GgAs3VSQWiMzSugfiVHWi8B5khTr5eGMrxM0pfQ=s360-p-rw-no"
                            src: user.display_name ? `https://avatars.dicebear.com/api/initials/${user.display_name.replaceAll(" ", "").replaceAll(",", " ").replaceAll("(", " ")}.svg` : "",
                            alt: ""
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                            className: "font-normal",
                            children: user.gid
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                            className: "font-normal text-slate-500",
                            children: user.display_name
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                            className: "font-normal text-slate-500",
                            children: user.email
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                className: "w-[100%] mt-8"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "p-4 flex flex-col gap-2 cursor-pointer",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex items-center gap-2",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "fa-solid fa-user"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    children: "Profile"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex items-center gap-2 ",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "fa-solid fa-arrow-right-from-bracket"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                    children: "Logout"
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    }));
};
/* harmony default export */ const floatingProfileView = (FloatingProfileView);

;// CONCATENATED MODULE: ./components/maincomponents/navbar.jsx

/* eslint-disable @next/next/link-passhref */ /* eslint-disable @next/next/no-img-element */ 



const Navbar = ()=>{
    const { 0: floatProfile , 1: SetfloatProfile  } = (0,external_react_.useState)(false);
    const { 0: user , 1: setuser  } = (0,external_react_.useState)("");
    function parseJwt(token) {
        var base64Url = token.split(".")[1];
        var base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
        var jsonPayload = decodeURIComponent(atob(base64).split("").map(function(c) {
            return "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2);
        }).join(""));
        setuser(JSON.parse(jsonPayload));
        return JSON.parse(jsonPayload);
    }
    // console.log(
    //   user.display_name
    //     ? `https://avatars.dicebear.com/api/initials/${user.display_name
    //         .replaceAll(" ", "")
    //         .replaceAll(",", " ")}.svg`
    //     : ""
    // );
    (0,external_react_.useEffect)(()=>{
        parseJwt(localStorage.getItem("access_token"));
    }, []);
    return(/*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "w-[100%] h-[3.8rem] drop-shadow-sm",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " w-[100%] h-[3.8rem] fixed bg-white",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "h-[3.8rem] flex justify-between items-center p-auto max-w-[98vw]",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex gap-7 items-center",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                href: "/",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                    crossOrigin: "anonymous",
                                                    src: "/logo.svg",
                                                    className: "cursor-pointer w-[10rem] h-[2rem] ml-[.8rem] ",
                                                    alt: ""
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                href: "/",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                    className: "cursor-pointer hover:text-blue-900",
                                                    children: "Overview"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                href: "/",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                    className: "cursor-pointer hover:text-blue-900",
                                                    children: "Microservices"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                href: "/",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                    className: "cursor-pointer hover:text-blue-900",
                                                    children: "Projects"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                href: "/",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                    className: "cursor-pointer hover:text-blue-900",
                                                    children: "Sandbox"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                href: "/",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                    className: "cursor-pointer hover:text-blue-900",
                                                    children: "Datasets"
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                onClick: ()=>{
                                                    SetfloatProfile((x)=>{
                                                        if (x === true) {
                                                            return false;
                                                        } else {
                                                            return true;
                                                        }
                                                    });
                                                },
                                                crossOrigin: "anonymous",
                                                className: "rounded-[150%] w-[3.2rem] h-[3.2rem] m-4 object-cover cursor-pointer",
                                                // src="https://lh3.googleusercontent.com/a-/AOh14GgAs3VSQWiMzSugfiVHWi8B5khTr5eGMrxM0pfQ=s360-p-rw-no"
                                                src: user.display_name ? `https://avatars.dicebear.com/api/initials/${user.display_name.replaceAll(" ", "").replaceAll(",", " ").replaceAll("(", " ")}.svg` : "",
                                                alt: ""
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "component z-2",
                                                children: floatProfile ? /*#__PURE__*/ jsx_runtime_.jsx(floatingProfileView, {}) : ""
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: " bg-black",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                    className: "h-[1.19px] bg-black"
                                })
                            })
                        ]
                    })
                })
            })
        })
    }));
};
/* harmony default export */ const navbar = (Navbar);

// EXTERNAL MODULE: ./context/allcontexts.js
var allcontexts = __webpack_require__(3534);
;// CONCATENATED MODULE: ./context/accessacc.js




const Userdatafunc = (props)=>{
    const { 0: userdata , 1: setuserdata  } = (0,external_react_.useState)("");
    const { 0: searchData , 1: setsearchData  } = (0,external_react_.useState)("");
    const { 0: canGoBack , 1: setcanGoBack  } = (0,external_react_.useState)(false);
    const { 0: login , 1: setlogin  } = (0,external_react_.useState)(false);
    const saveuserinfo = ()=>{
        if (localStorage.getItem("token") !== null) {
            external_jquery_default().ajax({
                type: "get",
                url: "/api/auth/user",
                headers: {
                    auth_token: localStorage.getItem("token")
                },
                success: (data)=>{
                    setuserdata(data);
                    setlogin(true);
                },
                error: (err)=>{
                    alert(err.responseText);
                }
            });
        }
    };
    return(/*#__PURE__*/ jsx_runtime_.jsx(allcontexts/* User.Provider */.n.Provider, {
        value: {
            userdata,
            saveuserinfo,
            login,
            canGoBack,
            setcanGoBack,
            searchData,
            setsearchData
        },
        children: props.children
    }));
};
/* harmony default export */ const accessacc = (Userdatafunc);

;// CONCATENATED MODULE: ./pages/_app.js


// import { RouteGuard } from '../components/RouteGaurd';




function MyApp({ Component , pageProps  }) {
    return(/*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(accessacc, {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(navbar, {}),
                /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                    ...pageProps
                })
            ]
        })
    }));
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 2947:
/***/ ((module) => {

module.exports = require("jquery");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [190,676,664], () => (__webpack_exec__(8522)));
module.exports = __webpack_exports__;

})();