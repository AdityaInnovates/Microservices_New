import { createContext } from "react";
export const User = createContext();
